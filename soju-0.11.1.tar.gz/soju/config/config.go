package config

import (
	"fmt"
	"net"
	"os"
	"path"
	"strconv"
	"strings"
	"time"

	"codeberg.org/emersion/go-scfg"

	"codeberg.org/emersion/soju/auth"
	"codeberg.org/emersion/soju/database"
	"codeberg.org/emersion/soju/fileupload"
	"codeberg.org/emersion/soju/msgstore"
)

var (
	DefaultPath          string
	DefaultUnixAdminPath = "/run/soju/admin"
)

type IPSet []*net.IPNet

func (set IPSet) Contains(ip net.IP) bool {
	for _, n := range set {
		if n.Contains(ip) {
			return true
		}
	}
	return false
}

// loopbackIPs contains the loopback networks 127.0.0.0/8 and ::1/128.
var loopbackIPs = IPSet{
	&net.IPNet{
		IP:   net.IP{127, 0, 0, 0},
		Mask: net.CIDRMask(8, 32),
	},
	&net.IPNet{
		IP:   net.IPv6loopback,
		Mask: net.CIDRMask(128, 128),
	},
}

func parseDuration(s string) (time.Duration, error) {
	if !strings.HasSuffix(s, "d") {
		return 0, fmt.Errorf("missing 'd' suffix in duration")
	}
	s = strings.TrimSuffix(s, "d")
	v, err := strconv.ParseFloat(s, 64)
	if err != nil {
		return 0, fmt.Errorf("invalid duration: %v", err)
	}
	return time.Duration(v * 24 * float64(time.Hour)), nil
}

type TLS struct {
	CertPath, KeyPath string
}

type DB struct {
	Driver database.Driver
	Source string
}

type MsgStore struct {
	Driver msgstore.Driver
	Source string
}

type Auth struct {
	Driver auth.Driver
	Source string
}

type FileUpload struct {
	Driver fileupload.Driver
	Source string
}

type BasicServer struct {
	Hostname                  string
	Title                     string
	MsgStore                  MsgStore
	HTTPOrigins               []string
	HTTPIngress               string
	AcceptProxyIPs            IPSet
	AcceptProxyUnix           bool
	MaxUserNetworks           int
	UpstreamUserIPs           []*net.IPNet
	DisableInactiveUsersDelay time.Duration
	MessageExpiry             time.Duration
	EnableUsersOnAuth         bool
	ClientCertAuth            bool
}

type Server struct {
	BasicServer

	Listen   []string
	TLS      *TLS
	Icon     string
	MOTDPath string

	DB         DB
	Auth       []Auth
	FileUpload *FileUpload
}

func Defaults() *Server {
	hostname, err := os.Hostname()
	if err != nil {
		hostname = "localhost"
	}
	return &Server{
		BasicServer: BasicServer{
			Hostname: hostname,
			MsgStore: MsgStore{
				Driver: msgstore.DriverDB,
			},
			HTTPIngress:     "https://" + hostname,
			MaxUserNetworks: -1,
		},
		DB: DB{
			Driver: database.DriverSQLite3,
			Source: "soju.db",
		},
		Auth: []Auth{{
			Driver: auth.DriverInternal,
		}},
	}
}

func Load(filename string) (*Server, error) {
	var raw struct {
		Listen []struct {
			Addr string `scfg:",param"`
		} `scfg:"listen"`
		Hostname     string     `scfg:"hostname"`
		Title        string     `scfg:"title"`
		Icon         string     `scfg:"icon"`
		MOTD         string     `scfg:"motd"`
		TLS          *[2]string `scfg:"tls"`
		DB           *[2]string `scfg:"db"`
		MessageStore []string   `scfg:"message-store"`
		Log          []string   `scfg:"log"`
		Auth         []struct {
			Params []string `scfg:",param"`
		} `scfg:"auth"`
		FileUpload          []string `scfg:"file-upload"`
		HTTPOrigin          []string `scfg:"http-origin"`
		HTTPIngress         string   `scfg:"http-ingress"`
		AcceptProxyIP       []string `scfg:"accept-proxy-ip"`
		AcceptProxyUnix     string   `scfg:"accept-proxy-unix"`
		MaxUserNetworks     int      `scfg:"max-user-networks"`
		UpstreamUserIP      []string `scfg:"upstream-user-ip"`
		DisableInactiveUser string   `scfg:"disable-inactive-user"`
		MessageExpiry       string   `scfg:"message-expiry"`
		EnableUserOnAuth    string   `scfg:"enable-user-on-auth"`
		ClientCertAuth      string   `scfg:"client-cert-auth"`
	}

	raw.MaxUserNetworks = -1

	f, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	if err := scfg.NewDecoder(f).Decode(&raw); err != nil {
		return nil, err
	}

	srv := Defaults()

	for _, listen := range raw.Listen {
		srv.Listen = append(srv.Listen, listen.Addr)
	}
	if raw.Hostname != "" {
		srv.Hostname = raw.Hostname
	}
	srv.Title = raw.Title
	srv.Icon = raw.Icon
	srv.MOTDPath = raw.MOTD
	if raw.TLS != nil {
		srv.TLS = &TLS{CertPath: raw.TLS[0], KeyPath: raw.TLS[1]}
	}
	if raw.DB != nil {
		driver := database.Driver(raw.DB[0])
		switch driver {
		case database.DriverSQLite3, database.DriverPostgres:
			// ok
		default:
			return nil, fmt.Errorf("directive db: unknown driver %q", driver)
		}
		srv.DB = DB{Driver: driver, Source: raw.DB[1]}
	}
	if raw.MessageStore == nil {
		raw.MessageStore = raw.Log
	}
	if raw.MessageStore != nil {
		driver, source, err := parseDriverSource("message-store", raw.MessageStore)
		if err != nil {
			return nil, err
		}
		switch msgstore.Driver(driver) {
		case msgstore.DriverMemory, msgstore.DriverDB:
			if source != "" {
				return nil, fmt.Errorf("directive message-store: driver %q requires zero parameters", driver)
			}
		case msgstore.DriverFS:
			if source == "" {
				return nil, fmt.Errorf("directive message-store: driver %q requires a source", driver)
			}
		default:
			return nil, fmt.Errorf("directive message-store: unknown driver %q", driver)
		}
		srv.MsgStore = MsgStore{Driver: msgstore.Driver(driver), Source: source}
	}
	if len(raw.Auth) != 0 {
		// drop default auth if we are explicitly defining any auth
		srv.Auth = nil
	}
	for _, authCfg := range raw.Auth {
		driver, source, err := parseDriverSource("auth", authCfg.Params)
		if err != nil {
			return nil, err
		}
		switch auth.Driver(driver) {
		case auth.DriverInternal, auth.DriverPAM:
			if source != "" {
				return nil, fmt.Errorf("directive auth: driver %q requires zero parameters", driver)
			}
		case auth.DriverHTTP, auth.DriverOAuth2:
			if source == "" {
				return nil, fmt.Errorf("directive auth: driver %q requires a source", driver)
			}
		default:
			return nil, fmt.Errorf("directive auth: unknown driver %q", driver)
		}
		srv.Auth = append(srv.Auth, Auth{Driver: auth.Driver(driver), Source: source})
	}
	if raw.FileUpload != nil {
		driver, source, err := parseDriverSource("file-upload", raw.FileUpload)
		if err != nil {
			return nil, err
		}
		switch fileupload.Driver(driver) {
		case fileupload.DriverFS, fileupload.DriverHTTP:
			if source == "" {
				return nil, fmt.Errorf("directive file-upload: driver %q requires a source", driver)
			}
		default:
			return nil, fmt.Errorf("directive file-upload: unknown driver %q", driver)
		}
		srv.FileUpload = &FileUpload{Driver: fileupload.Driver(driver), Source: source}
	}
	for _, origin := range raw.HTTPOrigin {
		if _, err := path.Match(origin, origin); err != nil {
			return nil, fmt.Errorf("directive http-origin: %v", err)
		}
	}
	srv.HTTPOrigins = raw.HTTPOrigin
	if raw.HTTPIngress != "" {
		srv.HTTPIngress = raw.HTTPIngress
	} else {
		srv.HTTPIngress = "https://" + srv.Hostname
	}
	for _, s := range raw.AcceptProxyIP {
		if s == "localhost" {
			srv.AcceptProxyIPs = append(srv.AcceptProxyIPs, loopbackIPs...)
			continue
		}
		_, n, err := net.ParseCIDR(s)
		if err != nil {
			return nil, fmt.Errorf("directive accept-proxy-ip: failed to parse CIDR: %v", err)
		}
		srv.AcceptProxyIPs = append(srv.AcceptProxyIPs, n)
	}
	if raw.AcceptProxyUnix != "" {
		b, err := strconv.ParseBool(raw.AcceptProxyUnix)
		if err != nil {
			return nil, fmt.Errorf("directive accept-proxy-unix: %v", err)
		}
		srv.AcceptProxyUnix = b
	}
	srv.MaxUserNetworks = raw.MaxUserNetworks
	var hasIPv4, hasIPv6 bool
	for _, s := range raw.UpstreamUserIP {
		_, n, err := net.ParseCIDR(s)
		if err != nil {
			return nil, fmt.Errorf("directive upstream-user-ip: failed to parse CIDR: %v", err)
		}
		if n.IP.To4() == nil {
			if hasIPv6 {
				return nil, fmt.Errorf("directive upstream-user-ip: found two IPv6 CIDRs")
			}
			hasIPv6 = true
		} else {
			if hasIPv4 {
				return nil, fmt.Errorf("directive upstream-user-ip: found two IPv4 CIDRs")
			}
			hasIPv4 = true
		}
		srv.UpstreamUserIPs = append(srv.UpstreamUserIPs, n)
	}
	if raw.DisableInactiveUser != "" {
		dur, err := parseDuration(raw.DisableInactiveUser)
		if err != nil {
			return nil, fmt.Errorf("directive disable-inactive-user: %v", err)
		} else if dur < 0 {
			return nil, fmt.Errorf("directive disable-inactive-user: duration must be positive")
		}
		srv.DisableInactiveUsersDelay = dur
	}
	if raw.MessageExpiry != "" {
		dur, err := parseDuration(raw.MessageExpiry)
		if err != nil {
			return nil, fmt.Errorf("directive message-expiry: %v", err)
		} else if dur < 0 {
			return nil, fmt.Errorf("directive message-expiry: duration must be positive")
		}
		srv.MessageExpiry = dur
	}
	if raw.EnableUserOnAuth != "" {
		b, err := strconv.ParseBool(raw.EnableUserOnAuth)
		if err != nil {
			return nil, fmt.Errorf("directive enable-user-on-auth: %v", err)
		}
		srv.EnableUsersOnAuth = b
	}
	if raw.ClientCertAuth != "" {
		b, err := strconv.ParseBool(raw.ClientCertAuth)
		if err != nil {
			return nil, fmt.Errorf("directive client-cert-auth: %v", err)
		}
		srv.ClientCertAuth = b
	}

	return srv, nil
}

func parseDriverSource(name string, params []string) (driver, source string, err error) {
	switch len(params) {
	case 2:
		source = params[1]
		fallthrough
	case 1:
		driver = params[0]
	default:
		err = fmt.Errorf("directive %v requires exactly 1 or 2 parameters", name)
	}
	return driver, source, err
}
